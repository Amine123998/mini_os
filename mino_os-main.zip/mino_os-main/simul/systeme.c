
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <time.h>

#include "cpu.h"
#include "asm.h"
#include "systeme.h"


/**********************************************************
** Structures de données de l'ordonnanceur (représentation
** d'un ensemble de threads).
**
** SUIVEZ L'ORDRE DES QUESTIONS DU SUJET DE TP.
***********************************************************/

#define MAX_THREADS  (20)   /* nb maximum de threads    */

typedef enum {
    EMPTY =   0,            /* thread non-prêt          */
    READY =   1,            /* thread prêt              */
} STATE;                    /* État d'un thread         */

typedef struct {
    PSW    cpu;             /* mot d'état du processeur */
    STATE  state;           /* état du thread           */
} PCB;                      /* Un Process Control Block */

PCB thread[MAX_THREADS];    /* table des threads        */

int current_thread = -1;    /* nu du thread courant     */


/**********************************************************
** Ajouter une entrée dans le tableau des threads.
**
** 1) trouver une case libre dans le tableau (EMPTY).
** 2) préparer cette case avec le PSW et l'état READY.
**
** SUIVEZ L'ORDRE DES QUESTIONS DU SUJET DE TP.
***********************************************************/

void new_thread(PSW cpu) {
    printf("Fonction %s à terminer.\n", __FUNCTION__);
    exit(EXIT_FAILURE);
}


/**********************************************************
** Tuer un thread
**
** SUIVEZ L'ORDRE DES QUESTIONS DU SUJET DE TP.
***********************************************************/

void kill_thread(int p) {
    if (p >= 0 && p < MAX_THREADS) {
        thread[p].state = EMPTY;
    }

    int active_threads = 0;
    for (int i = 0; i < MAX_THREADS; i++) {
        if (thread[i].state == READY) {
            active_threads++;
        }
    }

    if (active_threads == 0) {
        printf("No active threads, exiting simulator.\n");
        exit(EXIT_SUCCESS);
    }
}


/**********************************************************
** Réveiller les threads endormis.
**
** SUIVEZ L'ORDRE DES QUESTIONS DU SUJET DE TP.
***********************************************************/

void wakeup(void) {
    printf("Fonction %s à terminer.\n", __FUNCTION__);
    exit(EXIT_FAILURE);
}


/**********************************************************
** Ordonnancer l'exécution des threads.
**
** SUIVEZ L'ORDRE DES QUESTIONS DU SUJET DE TP.
***********************************************************/

PSW scheduler(PSW cpu) {
    // sauvegarder le thread courant s'il existe
    if(current_thread != -1) {
        thread[current_thread].cpu = cpu;
        thread[current_thread].state = READY;
    }

    //Checher un nouveau thread ready
    do {
        current_thread = (current_thread + 1) % MAX_THREADS;
    } while (thread[current_thread].state != READY);

    // relancer le nouveau thread
    return thread[current_thread].cpu;
}


/**********************************************************
** Démarrage du système (création d'un code)
***********************************************************/

PSW system_init(void) {
    printf("Booting\n");
    
    /*** création d'un code P1 ***/
    
    // le code (PC) démarre en 20 et le reste est à zéro
    PSW cpu1 = { .PC = 20 }; 
    PSW cpu2 = { .PC = 40 };

    thread[0].cpu = cpu1;
    thread[0].state = READY;

    thread[1].cpu = cpu2;
    thread[1].state = READY;

    current_thread = 0;
    
    
    assemble(cpu1.PC, "prog1.asm");
    assemble(cpu2.PC, "prog1.asm");
    
    return cpu1;
}


/**********************************************************
** Traitement des appels au système
**
** SUIVEZ L'ORDRE DES QUESTIONS DU SUJET DE TP.
***********************************************************/

enum {
    SYSC_EXIT       = 100,   // fin du thread courant
    SYSC_PUTI       = 200,   // afficher le contenu de AC
    SYSC_NEW_THREAD = 300,
};


PSW sysc_exit(PSW cpu) {
    kill_thread(current_thread);
    return scheduler(cpu);
}


PSW sysc_puti(PSW cpu) {
    printf("%d\n", cpu.AC);
    exit(EXIT_SUCCESS);
}


PSW sysc_putc(PSW cpu) {
    printf("Fonction %s à terminer.\n", __FUNCTION__);
    exit(EXIT_FAILURE);
}


PSW new_thread(PSW cpu) {
    for (int i = 0; i < MAX_THREADS; i++) {
        if (thread[i].state == EMPTY) {
            thread[i].cpu = cpu;
            thread[i].state = READY;
            return;
        }
    }
    fprintf(stderr, "Error: Maximum number of threads reached.\n");
    exit(EXIT_FAILURE);
}


PSW sysc_sleep(PSW cpu) {
    printf("Fonction %s à terminer.\n", __FUNCTION__);
    exit(EXIT_FAILURE);
}



PSW sysc_getchar(PSW cpu) {
    printf("Fonction %s à terminer.\n", __FUNCTION__);
    exit(EXIT_FAILURE);
}


void duplicate_thread(int parent_index) {
    thread[MAX_THREADS].cpu = thread[parent_index].cpu;
    thread[MAX_THREADS].state = READY;
}

void sysc_new_thread() {
    thread[current_thread].cpu.AC = 1;
    duplicate_thread(current_thread);
    thread[MAX_THREADS].cpu.AC = 0;
}


static PSW system_call(PSW cpu) {
    // suivant l'argument de sysc ARG
    switch (cpu.RI.arg) {
        case SYSC_EXIT:
            cpu = sysc_exit(cpu);
            break;
        case SYSC_PUTI:
            cpu = sysc_puti(cpu);
            break;
        default:
            printf("Appel système inconnu %d\n", cpu.RI.arg);
            break;
    }
    return cpu;
}


/**********************************************************
** Traitement des interruptions par le système (mode système)
***********************************************************/

PSW process_interrupt(PSW cpu) {
    switch (cpu.IN) {
        case INT_SEGV:
            printf("Recived SEGMENTATION FAULT interrupt (%d)\n", cpu.IN); //When we try to read or write to an invalid or protected memory location
            exit(EXIT_FAILURE);
            break;
        case INT_INST:
            printf("Recived INSTRUCTION FAULT interrupt (%d)\n", cpu.IN);
            exit(EXIT_FAILURE);
            break;
        case INT_TRACE:
            printf("Recived TRACE interrupt (%d)\n", cpu.IN);
            dump_cpu(cpu); sleep(1);
            cpu = scheduler(cpu);
            break;
        case INT_SYSC:
            printf("Recived SYSTEM CALL interrupt (%d)\n", cpu.IN);
            cpu = system_call(cpu);
            break;
        case INT_KEYBOARD:
            printf("Recived UNKNOWN interrupt (%d)\n", cpu.IN);
            break;
        default:
            break;
    }
    return cpu;
}
